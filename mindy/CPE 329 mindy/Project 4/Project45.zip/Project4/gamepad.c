#include "gamepad.h"
#include <ti/devices/msp432p4xx/inc/msp.h>
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include <stdlib.h>

int *vals;

/*
 * Internal function to set up adc processing for joystick
 */
void setupADC() {
    /* Initializing ADC (ADCOSC/64/8) */
    MAP_ADC14_enableModule();
    MAP_ADC14_initModule(ADC_CLOCKSOURCE_ADCOSC, ADC_PREDIVIDER_64, ADC_DIVIDER_8, 0);

    /* Configuring ADC Memory (ADC_MEM0 - ADC_MEM1 (A15, A9)  with repeat)
         * with internal 2.5v reference */
    MAP_ADC14_configureMultiSequenceMode(ADC_MEM0, ADC_MEM1, true);
    MAP_ADC14_configureConversionMemory(ADC_MEM0,
            ADC_VREFPOS_AVCC_VREFNEG_VSS,
            ADC_INPUT_A7, ADC_NONDIFFERENTIAL_INPUTS);

    MAP_ADC14_configureConversionMemory(ADC_MEM1,
            ADC_VREFPOS_AVCC_VREFNEG_VSS,
            ADC_INPUT_A8, ADC_NONDIFFERENTIAL_INPUTS);

    /* Enabling the interrupt when a conversion on channel 1 (end of sequence)
     *  is complete and enabling conversions */
    MAP_ADC14_enableInterrupt(ADC_INT1);

    /* Enabling Interrupts */
    MAP_Interrupt_enableInterrupt(INT_ADC14);
    MAP_Interrupt_enableMaster();

    /* Setting up the sample timer to automatically step through the sequence
     * convert.
     */
    MAP_ADC14_enableSampleTimer(ADC_AUTOMATIC_ITERATION);

    /* Triggering the start of the sample */
    MAP_ADC14_enableConversion();
    MAP_ADC14_toggleConversionTrigger();
}

/*
 * Sets up gamepad system for remote input
 * Uses P4.1-P4.6
 * P4.1 - A
 * P4.2 - B
 * P4.3 - C
 * P4.4 - D
 * P4.5 - X
 * P4.6 - Y
 *
 * Returns storage for x and y values after adc processing
 */
int* setupGamepad() {
    /*Input*/
    P4->SEL1 &= ~(BIT1 | BIT2 | BIT3 | BIT4);
    P4->SEL0 &= ~(BIT1 | BIT2 | BIT3 | BIT4);
    P4->DIR &= ~(BIT1 | BIT2 | BIT3 | BIT4);
    P4->OUT |= (BIT1 | BIT2 | BIT3 | BIT4);
    P4->REN |= (BIT1 | BIT2 | BIT3 | BIT4);

    /* Configures Pin 6.0 and 4.4 as ADC input */
    MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN5, GPIO_TERTIARY_MODULE_FUNCTION);
    MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN6, GPIO_TERTIARY_MODULE_FUNCTION);
    /* Initializing ADC (ADCOSC/64/8) */
    MAP_ADC14_enableModule();
    MAP_ADC14_initModule(ADC_CLOCKSOURCE_ADCOSC, ADC_PREDIVIDER_64, ADC_DIVIDER_8, 0);
    /* Configures Pin 4.5 and 4.6 as ADC input */
    MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN5, GPIO_TERTIARY_MODULE_FUNCTION);
    MAP_GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P4, GPIO_PIN6, GPIO_TERTIARY_MODULE_FUNCTION);

    /*initialize adc*/
    setupADC();

    /*make room for adc readings from main*/
    vals = malloc(sizeof(int) * 2);
    return vals;
}

/*
 * Polls for a key from gamepad
 * Returns a value defined in gamepad.h
 */
int getKey() {
    /*key pressed*/
    int key = NO_KEY;

    /*see if a key is pressed*/
    if (!(P4->IN & BIT1)) {
        key = KEY_A;
    }
    else if (!(P4->IN & BIT2)) {
        key = KEY_B;
    }
    else if (!(P4->IN & BIT3)) {
        key = KEY_C;
    }
    else if (!(P4->IN & BIT4)) {
        key = KEY_D;
    }
    /*see if x axis moved*/
    else if (vals[0] < 2000) {
        key = LEFT_X;
    }
    else if (vals[0] > 14000) {
        key = RIGHT_X;
    }
    /*see if y axis moved*/
    else if (vals[1] < 2000) {
        key = DOWN_Y;
    }
    else if (vals[1] > 14000) {
        key = UP_Y;
    }

    return key;
}
