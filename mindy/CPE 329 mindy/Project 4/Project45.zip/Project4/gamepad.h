#ifndef GAMEPAD_H_
#define GAMEPAD_H_

#define NO_KEY 0
#define KEY_A 1
#define KEY_B 2
#define KEY_C 3
#define KEY_D 4
#define LEFT_X 5
#define RIGHT_X 6
#define UP_Y 7
#define DOWN_Y 8

/*
 * Sets up gamepad system for remote input
 * Uses P4.1-P4.6
 * P4.1 - A
 * P4.2 - B
 * P4.3 - C
 * P4.4 - D
 *
 * returns a pointer to an X-Y value array
 * 2 integer array, X in 0, Y in 1
 * main is tasked with using ADC interrupts
 * to populate array
 */
int* setupGamepad();

/*
 * Polls for a key from gamepad
 * Returns a value defined at the top of this file
 */
int getKey();

#endif /* GAMEPAD_H_ */
