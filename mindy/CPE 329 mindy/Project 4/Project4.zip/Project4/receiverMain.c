#include <ti/devices/msp432p4xx/inc/msp.h>
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#define SIGNALDELAY 100
#define WAITDELAY 10000

void receiverMain(void) {
    /*P5.5 input*/
    P5->SEL0 &= ~BIT5;
    P5->SEL1 &= ~BIT5;
    P5->DIR &= ~BIT5;
    /*P6.0 output*/
    P6->SEL0 &= ~BIT0;
    P6->SEL1 &= ~BIT0;
    P6->DIR |= BIT0;
    P6->OUT &= ~BIT0;

    int counter;
    while (1) {
        /*wait until input signal goes low*/
        while (P5->IN & BIT5);

        /*bring P6.0 high for a bit*/
        P6->OUT |= BIT0;
        for (counter = 0; counter < SIGNALDELAY; counter++);
        P6->OUT &= ~BIT0;

        /*wait awhile to avoid sending multiple signals*/
        for (counter = 0; counter < WAITDELAY; counter++);
    }
}
