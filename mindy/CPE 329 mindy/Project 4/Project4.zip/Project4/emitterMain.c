#include <ti/devices/msp432p4xx/inc/msp.h>
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include "gamepad.h"

#define SIGNALDELAY 10000

/* ADC results buffer */
int *vals;

/*
 * Main function
 */
int emitterMain(void)
{
    /*P2.3 output, high drive*/
    P2->SEL0 &= ~BIT3;
    P2->SEL1 &= ~BIT3;
    P2->DS |= BIT3;
    P2->DIR |= BIT3;
    P2->OUT &= ~BIT3;

    /*initialize gamepad */
    vals = setupGamepad();

    /*infinite loop*/
    while(1)
    {
        /*get any key pressed*/
        int key = getKey();

        /*if A is pressed, emit a signal*/
        if (key == KEY_A) {
            int counter;

            /*Turn on IR*/
            P2->OUT |= BIT3;

            /*Hold on for awhile*/
            for (counter = 0; counter < SIGNALDELAY; counter++);

            /*Turn off IR*/
            P2->OUT &= ~BIT3;
        }
    }
}


/* This interrupt is fired whenever a conversion is completed and placed in
 * ADC_MEM1. This signals the end of conversion and the results array is
 * grabbed and placed in resultsBuffer */
void ADC14_IRQHandler(void)
{
    uint64_t status;

    /*check status*/
    status = MAP_ADC14_getEnabledInterruptStatus();
    MAP_ADC14_clearInterruptFlag(status);

    /* ADC_MEM1 conversion completed */
    if(status & ADC_INT1)
    {
        /* Store ADC14 conversion results */
    	vals[0] = ADC14_getResult(ADC_MEM1);
    	vals[1] = ADC14_getResult(ADC_MEM0);
    }
}
