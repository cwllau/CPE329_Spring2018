/*
 * terminal.h
 *
 *  Created on: May 19, 2017
 *      Author: Brendan
 */

#ifndef TERMINAL_H_
#define TERMINAL_H_

void terminal_init();
void printVals(DCoffset, peakToPeak, trueRMS, calcRMS, dc, frequency);

#endif /* TERMINAL_H_ */
