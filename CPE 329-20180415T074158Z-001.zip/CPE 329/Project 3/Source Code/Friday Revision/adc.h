#ifndef ADC_H_
#define ADC_H_

void ADC_init();
int adcReadVal();

#endif /* ADC_H_ */
