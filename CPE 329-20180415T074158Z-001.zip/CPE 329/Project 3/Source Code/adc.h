#ifndef ADC_H_
#define ADC_H_

/*Initialize ADC to pin 5.4 for reading*/
void ADC_init();

#endif /* ADC_H_ */
