#ifndef UART_H_
#define UART_H_

/* Sets up UART0
 */
void UART0_init();

/* Sends c over uart
 */
void uartPrint(char c);

#endif /* UART_H_ */
